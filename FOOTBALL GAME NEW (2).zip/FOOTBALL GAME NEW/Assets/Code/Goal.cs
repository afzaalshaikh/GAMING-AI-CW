﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(BoxCollider), typeof(Rigidbody))]
public class Goal : MonoBehaviour
{
    public Enums.TeamSide side;

    [SerializeField]
    private string levelToLoadOnGoal;

    /* If object of tag ball hits the goal, restart the game */
    private void OnTriggerEnter(Collider collider)
    {
        if (collider.transform.tag == "Ball")
            SceneManager.LoadScene(levelToLoadOnGoal);
    }
}
