﻿using UnityEngine;
using System.Collections;
using System;

[RequireComponent(typeof(Rigidbody))]
public class Ball : MonoBehaviour
{
    public System.Action<Character> OnOwnerChange = delegate { };

    private Character owner = null;
    private Rigidbody rigidBody;

    private void Awake()
    {
        if (rigidBody == null)
            rigidBody = this.GetComponent<Rigidbody>();

        /* Enable the rigidbody with gravity if the ball has no owner */
        OnOwnerChange += (character) =>
        {
            rigidBody.isKinematic = (character != null);
            rigidBody.useGravity = !(character != null);
        };
    }

    public void SetOwner(Character _owner)
    {
        if (_owner != null)
        {
            transform.position = _owner.BallSlot.position;
            transform.SetParent(_owner.BallSlot);
        }
        else
        {
            transform.SetParent(null);
        }

        owner = _owner;
        OnOwnerChange(owner);
    }

    public void Shoot(Vector3 target, float force)
    {
        SetOwner(null);
        rigidBody.AddForce((target - this.transform.position) * force, ForceMode.Impulse);
    }

}
