﻿using UnityEngine;
using System.Collections;

public class Enums : MonoBehaviour
{
    public enum TeamSide { Blue, Red };
    public enum CharacterBehaviour { SeekingBall, SeekingGoal };
}
