﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using KD_Steering;

public class Character : MonoBehaviour
{
    [SerializeField]
    private Enums.TeamSide teamSide;

    private Enums.CharacterBehaviour behaviourState = Enums.CharacterBehaviour.SeekingBall;

    private SteeringCore steeringCore;

    private Transform ballSlot;
    public UnityEngine.Transform BallSlot
    {
        get { return ballSlot; }
    }

    private Transform enemyGoal;

    private Ball ball;

    [SerializeField]
    private float ballGoalShootDistance = 10;

    [SerializeField]
    private float ballShootForce = 5;

    private List<Character> teamPlayers = new List<Character>();

    void Awake()
    {
        /* Get the steering core of this character */
        if (steeringCore == null)
        {
            steeringCore = this.GetComponent<SteeringCore>();
        }

        /* Get the ball slot of this character */
        if (ballSlot == null)
        {
            ballSlot = this.gameObject.GetComponentInChildren<BallSlot>().transform;
        }

        /* Get the ball in the world */
        if (ball == null)
        {
            ball = GameObject.FindObjectOfType<Ball>();
            ball.OnOwnerChange += OnBallOwnerChange;
        }

        /* Gets all team players in the scene, by checking if 'teamSide' matches */
        if (teamPlayers == null)
        {
            Character[] getAllCharacters = GameObject.FindObjectsOfType<Character>();
            for (int i = 0; i < getAllCharacters.Length; i++)
            {
                if (getAllCharacters[i].teamSide == teamSide)
                {
                    teamPlayers.Add(getAllCharacters[i]);
                }
            }
        }

        Goal[] getGoals = GameObject.FindObjectsOfType<Goal>();
        for (int i = 0; i < getGoals.Length; i++)
        {
            if (getGoals[i].side != teamSide)
            {
                Debug.Log(getGoals[i]);
                enemyGoal = getGoals[i].transform;
            }
        }

        if (this.GetComponent<SteeringBehavior_PathFollowing>() == null)
        {
            steeringCore.ChangedDirection(ball.transform);
            steeringCore.m_MaxSpeed = Random.Range(5f, 7f);
        }
    }

    void OnTriggerEnter(Collider collider)
    {
        if (collider.tag == "Ball")
        {
            Ball ball = collider.GetComponent<Ball>();
            if (ball != null)
            {
                ball.SetOwner(this);
            }
        }
    }

    public void OnBallOwnerChange(Character character)
    {
        if (character == this)
        {
            SetBehaviour(Enums.CharacterBehaviour.SeekingGoal);
            return;
        }

        SetBehaviour(Enums.CharacterBehaviour.SeekingBall);

        steeringCore.ChangedDirection(ball.transform);
        steeringCore.m_MaxSpeed = 5f;

    }

    private void SetBehaviour(Enums.CharacterBehaviour behaviour)
    {
        StopAllCoroutines();

        behaviourState = behaviour;

        switch (behaviour)
        {
            case Enums.CharacterBehaviour.SeekingBall:

                StartCoroutine(SeekBallBehaviour());

                break;
            case Enums.CharacterBehaviour.SeekingGoal:

                StartCoroutine(ObtainedBallBehaviour());

                break;
            default:
                break;
        }
    }

    IEnumerator ObtainedBallBehaviour()
    {
        while (behaviourState == Enums.CharacterBehaviour.SeekingGoal)
        {
            steeringCore.ChangedDirection(enemyGoal.transform);
            steeringCore.m_MaxSpeed = 5f;

            float thisDistanceToGoal = GetDistanceToGoal();

            /* Shoot at the goal if the character is near enough */
            if (thisDistanceToGoal < ballGoalShootDistance)
            {
                ball.Shoot(enemyGoal.transform.position, ballShootForce);
            } else
            {
                TryShootToCloserTeamMember(thisDistanceToGoal);
            }

            yield return new WaitForSeconds(0.25f);
        }
    }

    IEnumerator SeekBallBehaviour ()
    {
        while (behaviourState == Enums.CharacterBehaviour.SeekingBall)
        {
            steeringCore.ChangedDirection(ball.transform);
            steeringCore.m_MaxSpeed = 6f;

            yield return new WaitForSeconds(0.25f);
        }
    }

    public float GetDistanceToGoal ()
    {
        return Vector3.Distance(this.transform.position, enemyGoal.transform.position);
    }

    private void TryShootToCloserTeamMember(float thisDistanceToGoal)
    {
        for (int i = 0; i < teamPlayers.Count; i++)
        {
            if (teamPlayers[i].GetDistanceToGoal() < thisDistanceToGoal)
            {
                this.transform.LookAt(teamPlayers[i].transform);
                ball.Shoot(teamPlayers[i].transform.position, ballShootForce);
            }
        }
    }
}
